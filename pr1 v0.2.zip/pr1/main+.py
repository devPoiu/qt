import sys
import sqlite3
from ui import Ui_Form 
from imput import Ui_Dialog
from PyQt6 import QtCore, QtGui, QtWidgets, uic
from PyQt6.QtWidgets import QTableView
from PyQt6.QtGui import QStandardItemModel, QStandardItem
from tables.provider import provider
from tables.locker import locker
from tables.commutator import commutator
from tables.powerUnit import powerUnit
from tables.product import product

app = QtWidgets.QApplication(sys.argv)
Form = QtWidgets.QWidget()
ui = Ui_Form()
ui.setupUi(Form)

ui.menu.currentRowChanged.connect(ui.stackedWidget.setCurrentIndex)



# SELECT provider -------------------------------------

provider(ui)    

# SELECT locker -------------------------------------

locker(ui)

# SELECT commutator -------------------------------------

commutator(ui)

# SELECT powerUnit -------------------------------------

powerUnit(ui)

# SELECT product -------------------------------------
product(ui)

# db = sqlite3.connect('#dataBase.db')
# cursor = db.cursor()
# cursor.execute('''
# select * 
# from product pr
# ;''')
# tableProduct = cursor.fetchall()
# db.commit()
# db.close()

# modelTableProduct = QStandardItemModel()
# modelTableProduct.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Шкаф', 'Коммутатор', 'Блок питания', ''])
# for tab in tableProduct:
#     items = []
#     for item in tab:
#         items.append(QStandardItem(str(item)))
#     modelTableProduct.appendRow(items)

# ui.TVProduct.setModel(modelTableProduct)

# for num, tab in enumerate(tableProduct):
#     but = QtWidgets.QPushButton('Изменить')
#     index = modelTableProduct.index(num, 5)
#     ui.TVProduct.setIndexWidget(index, but)

# SELECT sale -------------------------------------

db = sqlite3.connect('#dataBase.db')
cursor = db.cursor()
cursor.execute('''
select * 
from sale s
;''')
tableSale = cursor.fetchall()
db.commit()
db.close()

modelTableSale = QStandardItemModel()
modelTableSale.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Покупатель', 'Кол-во', 'Цена', ''])
for tab in tableSale:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableSale.appendRow(items)

ui.TVSale.setModel(modelTableSale)

for num, tab in enumerate(tableSale):
    but = QtWidgets.QPushButton('Изменить')
    index = modelTableSale.index(num, 5)
    ui.TVSale.setIndexWidget(index, but)

# SELECT buyer -------------------------------------
db = sqlite3.connect('#dataBase.db')
cursor = db.cursor()
cursor.execute('''
select * 
from buyer b
;''')
tableBuyer = cursor.fetchall()
db.commit()
db.close()

modelTableBuyer = QStandardItemModel()
modelTableBuyer.setHorizontalHeaderLabels(['id', 'ИНН', 'Имя', 'Фамилия', 'Отчество', 'Телефон', ''])
for tab in tableBuyer:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableBuyer.appendRow(items)

ui.TVBuyer.setModel(modelTableBuyer)

for num, tab in enumerate(tableBuyer):
    but = QtWidgets.QPushButton('Изменить')
    index = modelTableBuyer.index(num, 6)
    ui.TVBuyer.setIndexWidget(index, but)
    


Form.show()
sys.exit(app.exec())