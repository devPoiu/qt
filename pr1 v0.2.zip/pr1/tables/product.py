import sqlite3
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem

def product(ui):
    db = sqlite3.connect('#dataBase.db')
    cursor = db.cursor()
    cursor.execute('''
    select * 
    from product pr
    ;''')
    tableProduct = cursor.fetchall()
    db.commit()
    db.close()

    modelTableProduct = QStandardItemModel()
    modelTableProduct.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Шкаф', 'Коммутатор', 'Блок питания', ''])
    for tab in tableProduct:
        items = []
        for item in tab:
            items.append(QStandardItem(str(item)))
        modelTableProduct.appendRow(items)

    ui.TVProduct.setModel(modelTableProduct)

    for num, tab in enumerate(tableProduct):
        but = QtWidgets.QPushButton('Изменить')
        index = modelTableProduct.index(num, 5)
        ui.TVProduct.setIndexWidget(index, but)