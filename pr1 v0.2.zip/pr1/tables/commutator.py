import sqlite3
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem

def commutator(ui):
    db = sqlite3.connect('#dataBase.db')
    cursor = db.cursor()
    cursor.execute('''
    select * 
    from commutator c
        --join provider p on c.providerID = p.id
    ;''')
    tableCommutator = cursor.fetchall()
    db.commit()
    db.close()


    modelTableCommutator = QStandardItemModel()
    modelTableCommutator.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Поставщик', 'Кол-во', ''])
    for tab in tableCommutator:
        items = []
        for item in tab:
            items.append(QStandardItem(str(item)))
        modelTableCommutator.appendRow(items)

    ui.TVCommutator.setModel(modelTableCommutator)

    for num, tab in enumerate(tableCommutator):
        but = QtWidgets.QPushButton('Изменить')
        index = modelTableCommutator.index(num, 4)
        ui.TVCommutator.setIndexWidget(index, but)