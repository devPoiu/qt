import sqlite3
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem

def locker(ui):
    db = sqlite3.connect('#dataBase.db')
    cursor = db.cursor()
    cursor.execute('''
    select * 
    from locker l
        --join provider p on l.providerID = p.id
    ;''')
    tableLocker = cursor.fetchall()
    db.commit()
    db.close()

    modelTableLocker = QStandardItemModel()
    modelTableLocker.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Поставщик', 'Кол-во', ''])
    for tab in tableLocker:
        items = []
        for item in tab:
            items.append(QStandardItem(str(item)))
        modelTableLocker.appendRow(items)

    ui.TVLocker.setModel(modelTableLocker)

    for num, tab in enumerate(tableLocker):
        but = QtWidgets.QPushButton('Изменить')
        index = modelTableLocker.index(num, 4)
        ui.TVLocker.setIndexWidget(index, but)