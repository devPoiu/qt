import sqlite3
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem

def powerUnit(ui):
    db = sqlite3.connect('#dataBase.db')
    cursor = db.cursor()
    cursor.execute('''
    select * 
    from powerUnit pu
        --join provider p on pu.providerID = p.id
    ;''')
    tablePowerUnit = cursor.fetchall()
    db.commit()
    db.close()


    modelTablePowerUnit = QStandardItemModel()
    modelTablePowerUnit.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Поставщик', 'Кол-во', ''])
    for tab in tablePowerUnit:
        items = []
        for item in tab:
            items.append(QStandardItem(str(item)))
        modelTablePowerUnit.appendRow(items)

    ui.TVPowerUnit.setModel(modelTablePowerUnit)

    for num, tab in enumerate(tablePowerUnit):
        but = QtWidgets.QPushButton('Изменить')
        index = modelTablePowerUnit.index(num, 4)
        ui.TVPowerUnit.setIndexWidget(index, but)
