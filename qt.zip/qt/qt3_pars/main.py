from PyQt6 import QtCore, QtGui, QtWidgets
from  ui import Ui_Form
import json
import requests

import sys
app = QtWidgets.QApplication(sys.argv)
Form = QtWidgets.QWidget()
form = Ui_Form()
form.setupUi(Form)

url = 'https://www.cbr-xml-daily.ru/daily_json.js'
response = requests.get(url, timeout=10)
data= json.loads(response.text)
valute = data['Valute']
print(valute)
valute['RUB'] = {
    "CharCode": "RUB",
    "Nominal": 1,
    "Name": "Рубль",
    "Value": 1,
    "Previous": 1
}
nameValute = valute.keys()
nameValuteRus = []
for name in nameValute:
    nameValuteRus.append(valute[name]['Name'])

form.valute1.addItems(sorted(nameValuteRus))
form.valute2.addItems(sorted(nameValuteRus))
form.sum1.setValue(1)

def res():
    sum1 = form.sum1.value()
    val1Ru = form.valute1.currentText()
    val2Ru = form.valute2.currentText()
    for val in valute.items():
        if val[1]['Name'] == val1Ru:
            val1 = val[0]
            print(val1)
        if val[1]['Name'] == val2Ru:
            val2 = val[0]
            print(val2)
    ress = (valute[val1]['Value'] / valute[val1]['Nominal']) / (valute[val2]['Value'] / valute[val2]['Nominal']) * sum1

    form.sum2.setValue(ress)

form.pushButton.clicked.connect(res)

Form.show()
sys.exit(app.exec())