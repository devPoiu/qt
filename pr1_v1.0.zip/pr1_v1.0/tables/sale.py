import sqlite3
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem

def sale(ui):
    
    ui.okSale.setVisible(False)
    global modelTableSale
    modelTableSale = QStandardItemModel()
    
    def createTable():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
                    select 
                        id, 
                        productID id_Товара, 
                        buyerID id_Покурателя, 
                        count Количество,
                        cost Цена
                    from 
                        sale;''')
        tableSale = cursor.fetchall()  
        db.commit()
        db.close()
        
        header = [f[0] for f in cursor.description] + ['']
        modelTableSale.clear()
        modelTableSale.setHorizontalHeaderLabels(header)
        for tab in tableSale:
            items = []
            for item in tab:
                items.append(QStandardItem(str(item)))
            modelTableSale.appendRow(items)
            
        ui.TVSale.setModel(modelTableSale)
        
        for num, tab in enumerate(tableSale):
            but = QtWidgets.QPushButton('Изменить')
            sale_id = tab[0]
            but.clicked.connect(lambda checked, n=sale_id : change_sale(n))
            index = modelTableSale.index(num, len(header)-1)
            ui.TVSale.setIndexWidget(index, but)
        
    def add_sale():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    INSERT INTO sale (productID, buyerID, count, cost)
    VALUES (?, ?, ?, ?);
    ''', (
            ui.productIDSale.text(),
            ui.buyerIDSale.text(),
            ui.countSale.text(),
            ui.costSale.text()
        ))
        db.commit()
        db.close()
        createTable()
        
    
    def change_sale(sale_id):
        ui.okSale.setVisible(True)
        try:
            ui.okSale.clicked.disconnect()
        except TypeError:
            pass
        ui.okSale.clicked.connect(lambda : update_sale(sale_id))
        sale_id-=1
        ui.productIDSale.setText(dataCell_sale(sale_id, 1)),
        ui.buyerIDSale.setText(dataCell_sale(sale_id, 2)),
        ui.countSale.setText(dataCell_sale(sale_id, 3)),
        ui.costSale.setText(dataCell_sale(sale_id, 4))
        
    def update_sale(row):
        row+=1
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    UPDATE 
        sale
    SET 
        productID = ?, 
        buyerID = ?, 
        count = ?,
        cost = ?
    WHERE 
        id = ?
    ''', (
            ui.productIDSale.text(),
            ui.buyerIDSale.text(),
            ui.countSale.text(),
            ui.costSale.text(),
            row
        ))
        db.commit()
        db.close()
        ui.productIDSale.setText('')
        ui.buyerIDSale.setText('')
        ui.countSale.setText('')
        ui.costSale.setText('')
        createTable()
        ui.okSale.setVisible(False)
        
    def dataCell_sale(row, column):
        index = modelTableSale.index(row, column)
        value = modelTableSale.data(index, QtCore.Qt.ItemDataRole.DisplayRole)
        return value
    
    ui.addSale.clicked.connect(add_sale)
    createTable()