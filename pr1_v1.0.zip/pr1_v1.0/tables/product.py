import sqlite3
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem

def product(ui):
    
    ui.okProduct.setVisible(False)
    global modelTableProduct
    modelTableProduct = QStandardItemModel()
    
    def createTable():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
                    select 
                        id, 
                        name Товар, 
                        lockerID id_Шкафа, 
                        commutatorID id_Коммутатора,
                        powerUnitID id_БП
                    from 
                        product;''')
        tableProduct = cursor.fetchall()  
        db.commit()
        db.close()
        
        header = [f[0] for f in cursor.description] + ['']
        modelTableProduct.clear()
        modelTableProduct.setHorizontalHeaderLabels(header)
        for tab in tableProduct:
            items = []
            for item in tab:
                items.append(QStandardItem(str(item)))
            modelTableProduct.appendRow(items)
            
        ui.TVProduct.setModel(modelTableProduct)
        
        for num, tab in enumerate(tableProduct):
            but = QtWidgets.QPushButton('Изменить')
            product_id = tab[0]
            but.clicked.connect(lambda checked, n=product_id : change_product(n))
            index = modelTableProduct.index(num, len(header)-1)
            ui.TVProduct.setIndexWidget(index, but)
        
    def add_product():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    INSERT INTO product (name, lockerID, commutatorID, powerUnitID)
    VALUES (?, ?, ?, ?);
    ''', (
            ui.nameProduct.text(),
            ui.lockerIDProduct.text(),
            ui.commutatorIDProduct.text(),
            ui.powerUnitIDProduct.text()
        ))
        db.commit()
        db.close()
        createTable()
        
    
    def change_product(product_id):
        ui.okProduct.setVisible(True)
        try:
            ui.okProduct.clicked.disconnect()
        except TypeError:
            pass
        ui.okProduct.clicked.connect(lambda : update_product(product_id))
        product_id-=1
        ui.nameProduct.setText(dataCell_product(product_id, 1)),
        ui.lockerIDProduct.setText(dataCell_product(product_id, 2)),
        ui.commutatorIDProduct.setText(dataCell_product(product_id, 3)),
        ui.powerUnitIDProduct.setText(dataCell_product(product_id, 4))
        
    def update_product(row):
        row+=1
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    UPDATE 
        product
    SET 
        name = ?, 
        lockerID = ?, 
        commutatorID = ?,
        powerUnitID = ?
    WHERE 
        id = ?
    ''', (
            ui.nameProduct.text(),
            ui.lockerIDProduct.text(),
            ui.commutatorIDProduct.text(),
            ui.powerUnitIDProduct.text(),
            row
        ))
        db.commit()
        db.close()
        ui.nameProduct.setText('')
        ui.lockerIDProduct.setText('')
        ui.commutatorIDProduct.setText('')
        ui.powerUnitIDProduct.setText('')
        createTable()
        ui.okProduct.setVisible(False)
        
    def dataCell_product(row, column):
        index = modelTableProduct.index(row, column)
        value = modelTableProduct.data(index, QtCore.Qt.ItemDataRole.DisplayRole)
        return value
    
    ui.addProduct.clicked.connect(add_product)
    createTable()