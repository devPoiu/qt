import sqlite3
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem

def powerUnit(ui):
    ui.okPowerUnit.setVisible(False)
    global modelTablePowerUnit
    modelTablePowerUnit = QStandardItemModel()
    
    def createTable():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
                    select 
                        id, 
                        name БП, 
                        providerID id_Поставщика, 
                        count Количество
                    from 
                        powerUnit;''')
        tablePowerUnit = cursor.fetchall()  
        db.commit()
        db.close()
        
        header = [f[0] for f in cursor.description] + ['']
        modelTablePowerUnit.clear()
        modelTablePowerUnit.setHorizontalHeaderLabels(header)
        for tab in tablePowerUnit:
            items = []
            for item in tab:
                items.append(QStandardItem(str(item)))
            modelTablePowerUnit.appendRow(items)
            
        ui.TVPowerUnit.setModel(modelTablePowerUnit)
        
        for num, tab in enumerate(tablePowerUnit):
            but = QtWidgets.QPushButton('Изменить')
            powerUnit_id = tab[0]
            but.clicked.connect(lambda checked, n=powerUnit_id : change_powerUnit(n))
            index = modelTablePowerUnit.index(num, len(header)-1)
            ui.TVPowerUnit.setIndexWidget(index, but)
        
    def add_powerUnit():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    INSERT INTO powerUnit (name, providerID, count)
    VALUES (?, ?, ?);
    ''', (
            ui.namePowerUnit.text(),
            ui.providerIDPowerUnit.text(),
            ui.countPowerUnit.text()
        ))
        db.commit()
        db.close()
        createTable()
        
    
    def change_powerUnit(powerUnit_id):
        ui.okPowerUnit.setVisible(True)
        try:
            ui.okPowerUnit.clicked.disconnect()
        except TypeError:
            pass
        ui.okPowerUnit.clicked.connect(lambda : update_powerUnit(powerUnit_id))
        powerUnit_id-=1
        ui.namePowerUnit.setText(dataCell_powerUnit(powerUnit_id, 1)),
        ui.providerIDPowerUnit.setText(dataCell_powerUnit(powerUnit_id, 2)),
        ui.countPowerUnit.setText(dataCell_powerUnit(powerUnit_id, 3))
        
    def update_powerUnit(row):
        row+=1
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    UPDATE 
        powerUnit
    SET 
        name = ?, 
        providerID = ?, 
        count = ?
    WHERE 
        id = ?
    ''', (
            ui.namePowerUnit.text(),
            ui.providerIDPowerUnit.text(),
            ui.countPowerUnit.text(),
            row
        ))
        db.commit()
        db.close()
        ui.namePowerUnit.setText('')
        ui.providerIDPowerUnit.setText('')
        ui.countPowerUnit.setText('')
        createTable()
        ui.okPowerUnit.setVisible(False)
        
    def dataCell_powerUnit(row, column):
        index = modelTablePowerUnit.index(row, column)
        value = modelTablePowerUnit.data(index, QtCore.Qt.ItemDataRole.DisplayRole)
        return value
    
    ui.addPowerUnit.clicked.connect(add_powerUnit)
    createTable()