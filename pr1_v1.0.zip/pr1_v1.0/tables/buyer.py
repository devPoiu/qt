import sqlite3
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem

def buyer(ui):
    ui.okBuyer.setVisible(False)
    global modelTableBuyer
    modelTableBuyer = QStandardItemModel()



    def createTable():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
                    select 
                        id, 
                        inn ИНН, 
                        fname Имя, 
                        lname Фамилия, 
                        patronymic Отчество, 
                        tel Телефон  
                    from 
                        buyer;''')
        tableBuyer = cursor.fetchall()  
        db.commit()
        db.close()

        header = [f[0] for f in cursor.description] + ['']
        modelTableBuyer.clear()
        modelTableBuyer.setHorizontalHeaderLabels(header)
        for tab in tableBuyer:
            items = []
            for item in tab:
                items.append(QStandardItem(str(item)))
            modelTableBuyer.appendRow(items)

        ui.TVBuyer.setModel(modelTableBuyer)

        for num, tab in enumerate(tableBuyer):
            but = QtWidgets.QPushButton('Изменить')
            buyer_id = tab[0]
            but.clicked.connect(lambda checked, n=buyer_id : change_buyer(n))
            index = modelTableBuyer.index(num, len(header)-1)
            ui.TVBuyer.setIndexWidget(index, but)
            
    def add_buyer():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    INSERT INTO buyer (inn, fname, lname, patronymic, tel)
    VALUES (?, ?, ?, ?, ?);
    ''', (
            ui.innBuyer.text(),
            ui.fnameBuyer.text(),
            ui.lnameBuyer.text(),
            ui.patronymicBuyer.text(),
            ui.telBuyer.text()
        ))
        db.commit()
        db.close()
        createTable()
        
        
        
    def change_buyer(buyer_id):
        ui.okBuyer.setVisible(True)
        try:
            ui.okBuyer.clicked.disconnect()
        except TypeError:
            pass
        ui.okBuyer.clicked.connect(lambda : update_buyer(buyer_id))
        buyer_id-=1
        ui.innBuyer.setText(dataCell_buyer(buyer_id, 1)),
        ui.fnameBuyer.setText(dataCell_buyer(buyer_id, 2)),
        ui.lnameBuyer.setText(dataCell_buyer(buyer_id, 3)),
        ui.patronymicBuyer.setText(dataCell_buyer(buyer_id, 4)),
        ui.telBuyer.setText(dataCell_buyer(buyer_id, 5))

    def update_buyer(row):
        row+=1
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    UPDATE 
        buyer
    SET 
        inn = ?,
        fname = ?,
        lname = ?,
        patronymic = ?,
        tel = ?
    WHERE 
        id = ?
    ''', (
            ui.innBuyer.text(),
            ui.fnameBuyer.text(),
            ui.lnameBuyer.text(),
            ui.patronymicBuyer.text(),
            ui.telBuyer.text(), 
            row
        ))
        db.commit()
        db.close()
        ui.innBuyer.setText('')
        ui.fnameBuyer.setText('')
        ui.lnameBuyer.setText('')
        ui.patronymicBuyer.setText('')
        ui.telBuyer.setText('')
        createTable()
        ui.okBuyer.setVisible(False)
        
    def dataCell_buyer(row, column):
        index = modelTableBuyer.index(row, column)
        value = modelTableBuyer.data(index, QtCore.Qt.ItemDataRole.DisplayRole)
        return value
        
    ui.addBuyer.clicked.connect(add_buyer)
    createTable()

    
    
    
    
    # db = sqlite3.connect('#dataBase.db')
    # cursor = db.cursor()
    # cursor.execute('''
    # select * 
    # from buyer b
    # ;''')
    # tableBuyer = cursor.fetchall()
    # db.commit()
    # db.close()

    # modelTableBuyer = QStandardItemModel()
    # modelTableBuyer.setHorizontalHeaderLabels(['id', 'ИНН', 'Имя', 'Фамилия', 'Отчество', 'Телефон', ''])
    # for tab in tableBuyer:
    #     items = []
    #     for item in tab:
    #         items.append(QStandardItem(str(item)))
    #     modelTableBuyer.appendRow(items)

    # ui.TVBuyer.setModel(modelTableBuyer)

    # for num, tab in enumerate(tableBuyer):
    #     but = QtWidgets.QPushButton('Изменить')
    #     index = modelTableBuyer.index(num, 6)
    #     ui.TVBuyer.setIndexWidget(index, but)