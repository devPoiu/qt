import sqlite3
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem

def locker(ui):
    ui.okLocker.setVisible(False)
    global modelTableLocker
    modelTableLocker = QStandardItemModel()
    
    def createTable():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
                    select 
                        id, 
                        name Шкаф, 
                        providerID id_Поставщика, 
                        count Количество
                    from 
                        locker;''')
        tableLocker = cursor.fetchall()  
        db.commit()
        db.close()
        
        header = [f[0] for f in cursor.description] + ['']
        modelTableLocker.clear()
        modelTableLocker.setHorizontalHeaderLabels(header)
        for tab in tableLocker:
            items = []
            for item in tab:
                items.append(QStandardItem(str(item)))
            modelTableLocker.appendRow(items)
            
        ui.TVLocker.setModel(modelTableLocker)
        
        for num, tab in enumerate(tableLocker):
            but = QtWidgets.QPushButton('Изменить')
            locker_id = tab[0]
            but.clicked.connect(lambda checked, n=locker_id : change_locker(n))
            index = modelTableLocker.index(num, len(header)-1)
            ui.TVLocker.setIndexWidget(index, but)
        
    def add_locker():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    INSERT INTO locker (name, providerID, count)
    VALUES (?, ?, ?);
    ''', (
            ui.nameLocker.text(),
            ui.providerIDLocker.text(),
            ui.countLocker.text()
        ))
        db.commit()
        db.close()
        createTable()
        
    
    def change_locker(locker_id):
        ui.okLocker.setVisible(True)
        try:
            ui.okLocker.clicked.disconnect()
        except TypeError:
            pass
        ui.okLocker.clicked.connect(lambda : update_locker(locker_id))
        locker_id-=1
        ui.nameLocker.setText(dataCell_locker(locker_id, 1)),
        ui.providerIDLocker.setText(dataCell_locker(locker_id, 2)),
        ui.countLocker.setText(dataCell_locker(locker_id, 3))
        
    def update_locker(row):
        row+=1
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    UPDATE 
        locker
    SET 
        name = ?, 
        providerID = ?, 
        count = ?
    WHERE 
        id = ?
    ''', (
            ui.nameLocker.text(),
            ui.providerIDLocker.text(),
            ui.countLocker.text(),
            row
        ))
        db.commit()
        db.close()
        ui.nameLocker.setText('')
        ui.providerIDLocker.setText('')
        ui.countLocker.setText('')
        createTable()
        ui.okLocker.setVisible(False)
        
    def dataCell_locker(row, column):
        index = modelTableLocker.index(row, column)
        value = modelTableLocker.data(index, QtCore.Qt.ItemDataRole.DisplayRole)
        return value
    
    ui.addLocker.clicked.connect(add_locker)
    createTable()