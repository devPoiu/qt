import sqlite3
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem

def commutator(ui):
    
    ui.okCommutator.setVisible(False)
    global modelTableCommutator
    modelTableCommutator = QStandardItemModel()
    
    def createTable():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
                    select 
                        id, 
                        name Коммутатор, 
                        providerID id_Поставщика, 
                        count Количество
                    from 
                        commutator;''')
        tableCommutator = cursor.fetchall()  
        db.commit()
        db.close()
        
        header = [f[0] for f in cursor.description] + ['']
        modelTableCommutator.clear()
        modelTableCommutator.setHorizontalHeaderLabels(header)
        for tab in tableCommutator:
            items = []
            for item in tab:
                items.append(QStandardItem(str(item)))
            modelTableCommutator.appendRow(items)
            
        ui.TVCommutator.setModel(modelTableCommutator)
        
        for num, tab in enumerate(tableCommutator):
            but = QtWidgets.QPushButton('Изменить')
            commutator_id = tab[0]
            but.clicked.connect(lambda checked, n=commutator_id : change_commutator(n))
            index = modelTableCommutator.index(num, len(header)-1)
            ui.TVCommutator.setIndexWidget(index, but)
        
    def add_commutator():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    INSERT INTO commutator (name, providerID, count)
    VALUES (?, ?, ?);
    ''', (
            ui.nameCommutator.text(),
            ui.providerIDCommutator.text(),
            ui.countCommutator.text()
        ))
        db.commit()
        db.close()
        createTable()
        
    
    def change_commutator(commutator_id):
        ui.okCommutator.setVisible(True)
        try:
            ui.okCommutator.clicked.disconnect()
        except TypeError:
            pass
        ui.okCommutator.clicked.connect(lambda : update_commutator(commutator_id))
        commutator_id-=1
        ui.nameCommutator.setText(dataCell_commutator(commutator_id, 1)),
        ui.providerIDCommutator.setText(dataCell_commutator(commutator_id, 2)),
        ui.countCommutator.setText(dataCell_commutator(commutator_id, 3))
        
    def update_commutator(row):
        row+=1
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    UPDATE 
        commutator
    SET 
        name = ?, 
        providerID = ?, 
        count = ?
    WHERE 
        id = ?
    ''', (
            ui.nameCommutator.text(),
            ui.providerIDCommutator.text(),
            ui.countCommutator.text(),
            row
        ))
        db.commit()
        db.close()
        ui.nameCommutator.setText('')
        ui.providerIDCommutator.setText('')
        ui.countCommutator.setText('')
        createTable()
        ui.okCommutator.setVisible(False)
        
    def dataCell_commutator(row, column):
        index = modelTableCommutator.index(row, column)
        value = modelTableCommutator.data(index, QtCore.Qt.ItemDataRole.DisplayRole)
        return value
    
    ui.addCommutator.clicked.connect(add_commutator)
    createTable()