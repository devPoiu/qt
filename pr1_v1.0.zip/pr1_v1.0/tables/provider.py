import sqlite3
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtGui import QStandardItemModel, QStandardItem


def provider(ui):
    ui.okProvider.setVisible(False)
    global modelTableProvider
    modelTableProvider = QStandardItemModel()



    def createTable():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
                    select 
                        id, 
                        inn ИНН, 
                        fname Имя, 
                        lname Фамилия, 
                        patronymic Отчество, 
                        tel Телефон  
                    from 
                        provider;''')
        tableProvider = cursor.fetchall()  
        db.commit()
        db.close()

        header = [f[0] for f in cursor.description] + ['']
        modelTableProvider.clear()
        modelTableProvider.setHorizontalHeaderLabels(header)
        for tab in tableProvider:
            items = []
            for item in tab:
                items.append(QStandardItem(str(item)))
            modelTableProvider.appendRow(items)

        ui.TVProvider.setModel(modelTableProvider)

        for num, tab in enumerate(tableProvider):
            but = QtWidgets.QPushButton('Изменить')
            provider_id = tab[0]
            but.clicked.connect(lambda checked, n=provider_id : change_provider(n))
            index = modelTableProvider.index(num, len(header)-1)
            ui.TVProvider.setIndexWidget(index, but)
            
    def add_provider():
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    INSERT INTO provider (inn, fname, lname, patronymic, tel)
    VALUES (?, ?, ?, ?, ?);
    ''', (
            ui.innProvider.text(),
            ui.fnameProvider.text(),
            ui.lnameProvider.text(),
            ui.patronymicProvider.text(),
            ui.telProvider.text()
        ))
        db.commit()
        db.close()
        createTable()
        
        
        
    def change_provider(provider_id):
        ui.okProvider.setVisible(True)
        try:
            ui.okProvider.clicked.disconnect()
        except TypeError:
            pass
        ui.okProvider.clicked.connect(lambda : update_provider(provider_id))
        provider_id-=1
        ui.innProvider.setText(dataCell_provider(provider_id, 1)),
        ui.fnameProvider.setText(dataCell_provider(provider_id, 2)),
        ui.lnameProvider.setText(dataCell_provider(provider_id, 3)),
        ui.patronymicProvider.setText(dataCell_provider(provider_id, 4)),
        ui.telProvider.setText(dataCell_provider(provider_id, 5))

    def update_provider(row):
        row+=1
        db = sqlite3.connect('#dataBase.db')
        cursor = db.cursor()
        cursor.execute('''
    UPDATE 
        provider
    SET 
        inn = ?,
        fname = ?,
        lname = ?,
        patronymic = ?,
        tel = ?
    WHERE 
        id = ?
    ''', (
            ui.innProvider.text(),
            ui.fnameProvider.text(),
            ui.lnameProvider.text(),
            ui.patronymicProvider.text(),
            ui.telProvider.text(), 
            row
        ))
        db.commit()
        db.close()
        ui.innProvider.setText('')
        ui.fnameProvider.setText('')
        ui.lnameProvider.setText('')
        ui.patronymicProvider.setText('')
        ui.telProvider.setText('')
        createTable()
        ui.okProvider.setVisible(False)
        
    def dataCell_provider(row, column):
        index = modelTableProvider.index(row, column)
        value = modelTableProvider.data(index, QtCore.Qt.ItemDataRole.DisplayRole)
        return value
        
    ui.addProvider.clicked.connect(add_provider)
    createTable()