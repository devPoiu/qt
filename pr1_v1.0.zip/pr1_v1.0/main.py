import sys
import sqlite3
from ui import Ui_Form
from PyQt6 import QtCore, QtGui, QtWidgets, uic
from PyQt6.QtWidgets import QTableView
from PyQt6.QtGui import QStandardItemModel, QStandardItem
from tables.provider import provider
from tables.locker import locker
from tables.commutator import commutator
from tables.powerUnit import powerUnit
from tables.product import product
from tables.sale import sale
from tables.buyer import buyer

app = QtWidgets.QApplication(sys.argv)
Form = QtWidgets.QWidget()
ui = Ui_Form()
ui.setupUi(Form)

ui.menu.currentRowChanged.connect(ui.stackedWidget.setCurrentIndex)

provider(ui)
locker(ui)
commutator(ui)
powerUnit(ui)
product(ui)
sale(ui)
buyer(ui)

Form.show()
sys.exit(app.exec())