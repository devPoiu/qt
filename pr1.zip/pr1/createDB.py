import sqlite3


db = sqlite3.connect('#dataBase.db')
cursor = db.cursor()
cursor.execute('''
create table if not exists provider(
    id integer primary key,
    inn integer not null,
    fname varchar(20) not null,
    lname varchar(20) not null,
    patronymic varchar(20) not null,
    tel integer not null
);
''')
cursor.execute('''
create table if not exists locker(
    id integer primary key,
    name varchar(20) not null,
    providerID integer references provider(id) not null,
    count integer not null
);
''')
cursor.execute('''
create table if not exists commutator(
    id integer primary key,
    name varchar(20) not null,
    providerID integer references provider(id) not null,
    count integer not null
);
''')
cursor.execute('''
create table if not exists powerUnit(
    id integer primary key,
    name varchar(20) not null,
    providerID integer references provider(id) not null,
    count integer not null
);
''')
cursor.execute('''
create table if not exists buyer(
    id integer primary key,
    inn integer not null,
    fname varchar(20) not null,
    lname varchar(20) not null,
    patronymic varchar(20) not null,
    tel integer not null
);
''')
cursor.execute('''
create table if not exists product(
    id integer primary key,
    name varchar(20) not null,
    lockerID integer references locker(id) not null,
    commutatorID integer references commutator(id) not null,
    powerUnitID integer references powerUnit(id) not null
);
''')
cursor.execute('''
create table if not exists sale(
    id integer primary key,
    productID integer references product(id) not null,
    buyerID integer references buyer(id) not null,
    count integer not null,
    cost float not null
);
''')

db.commit()
db.close()

print('БД создана')