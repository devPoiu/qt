import sys
import sqlite3
from ui import Ui_Form 
from PyQt6 import QtCore, QtGui, QtWidgets 
from PyQt6.QtWidgets import QTableView
from PyQt6.QtGui import QStandardItemModel, QStandardItem
import math

app = QtWidgets.QApplication(sys.argv)
Form = QtWidgets.QWidget()
ui = Ui_Form()
ui.setupUi(Form)

ui.menu.currentRowChanged.connect(ui.stackedWidget.setCurrentIndex)



db = sqlite3.connect('#dataBase.db')
cursor = db.cursor()

# SELECT provider -------------------------------------

# cursor.execute('select * from provider;')
# tableProvider = cursor.fetchall()

# modelTableProvider = QStandardItemModel()
# modelTableProvider.setHorizontalHeaderLabels(['id', 'ИНН', 'Имя', 'Фамилия', 'Отчество', 'Телефон'])
# for tab in tableProvider:
#     items = []
#     for item in tab:
#         items.append(QStandardItem(str(item)))
#     modelTableProvider.appendRow(items)

# ui.TVProvider.setModel(modelTableProvider)

# -------------TEST------------------

cursor.execute('select * from provider;')
tableProvider = cursor.fetchall()

modelTableProvider = QStandardItemModel()
modelTableProvider.setHorizontalHeaderLabels(['id', 'ИНН', 'Имя', 'Фамилия', 'Отчество', 'Телефон', ''])
for tab in tableProvider:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableProvider.appendRow(items)

ui.TVProvider.setModel(modelTableProvider)

def update(num):
    cursor.execute(f'''
UPDATE provider
SET fname = 'Dima'
WHERE id = 1;''')
    

for num, tab in enumerate(tableProvider):
    but = QtWidgets.QPushButton('Изменить')
    but.clicked.connect(update)
    index = modelTableProvider.index(num, 6)
    ui.TVProvider.setIndexWidget(index, but)
    

# SELECT locker -------------------------------------

cursor.execute('''
select * 
from locker l
    --join provider p on l.providerID = p.id
;''')
tableLocker = cursor.fetchall()

modelTableLocker = QStandardItemModel()
modelTableLocker.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Поставщик', 'Кол-во', ''])
for tab in tableLocker:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableLocker.appendRow(items)

ui.TVLocker.setModel(modelTableLocker)

for num, tab in enumerate(tableLocker):
    but = QtWidgets.QPushButton('Изменить')
    index = modelTableLocker.index(num, 4)
    ui.TVLocker.setIndexWidget(index, but)

# SELECT commutator -------------------------------------

cursor.execute('''
select * 
from commutator c
    --join provider p on c.providerID = p.id
;''')
tableCommutator = cursor.fetchall()

modelTableCommutator = QStandardItemModel()
modelTableCommutator.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Поставщик', 'Кол-во', ''])
for tab in tableCommutator:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableCommutator.appendRow(items)

ui.TVCommutator.setModel(modelTableCommutator)

for num, tab in enumerate(tableCommutator):
    but = QtWidgets.QPushButton('Изменить')
    index = modelTableCommutator.index(num, 4)
    ui.TVCommutator.setIndexWidget(index, but)

# SELECT powerUnit -------------------------------------

cursor.execute('''
select * 
from powerUnit pu
    --join provider p on pu.providerID = p.id
;''')
tablePowerUnit = cursor.fetchall()

modelTablePowerUnit = QStandardItemModel()
modelTablePowerUnit.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Поставщик', 'Кол-во', ''])
for tab in tablePowerUnit:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTablePowerUnit.appendRow(items)

ui.TVPowerUnit.setModel(modelTablePowerUnit)

for num, tab in enumerate(tablePowerUnit):
    but = QtWidgets.QPushButton('Изменить')
    index = modelTablePowerUnit.index(num, 4)
    ui.TVPowerUnit.setIndexWidget(index, but)

# SELECT product -------------------------------------

cursor.execute('''
select * 
from product pr
;''')
tableProduct = cursor.fetchall()

modelTableProduct = QStandardItemModel()
modelTableProduct.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Шкаф', 'Коммутатор', 'Блок питания', ''])
for tab in tableProduct:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableProduct.appendRow(items)

ui.TVProduct.setModel(modelTableProduct)

for num, tab in enumerate(tableProduct):
    but = QtWidgets.QPushButton('Изменить')
    index = modelTableProduct.index(num, 5)
    ui.TVProduct.setIndexWidget(index, but)

# SELECT sale -------------------------------------

cursor.execute('''
select * 
from sale s
;''')
tableSale = cursor.fetchall()

modelTableSale = QStandardItemModel()
modelTableSale.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Покупатель', 'Кол-во', 'Цена', ''])
for tab in tableSale:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableSale.appendRow(items)

ui.TVSale.setModel(modelTableSale)

for num, tab in enumerate(tableSale):
    but = QtWidgets.QPushButton('Изменить')
    index = modelTableSale.index(num, 5)
    ui.TVSale.setIndexWidget(index, but)

# SELECT buyer -------------------------------------

cursor.execute('''
select * 
from buyer b
;''')
tableBuyer = cursor.fetchall()

modelTableBuyer = QStandardItemModel()
modelTableBuyer.setHorizontalHeaderLabels(['id', 'ИНН', 'Имя', 'Фамилия', 'Отчество', 'Телефон', ''])
for tab in tableBuyer:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableBuyer.appendRow(items)

ui.TVBuyer.setModel(modelTableBuyer)

for num, tab in enumerate(tableBuyer):
    but = QtWidgets.QPushButton('Изменить')
    index = modelTableBuyer.index(num, 6)
    ui.TVBuyer.setIndexWidget(index, but)
    
    
db.commit()
db.close()


Form.show()
sys.exit(app.exec())