import sys
import sqlite3
from ui import Ui_Form 
from PyQt6 import QtCore, QtGui, QtWidgets 
from PyQt6.QtWidgets import QTableView
from PyQt6.QtGui import QStandardItemModel, QStandardItem
import math

app = QtWidgets.QApplication(sys.argv)
Form = QtWidgets.QWidget()
ui = Ui_Form()
ui.setupUi(Form)

ui.menu.currentRowChanged.connect(ui.stackedWidget.setCurrentIndex)



db = sqlite3.connect('#dataBase.db')
cursor = db.cursor()

# SELECT provider -------------------------------------

cursor.execute('select * from provider;')
tableProvider = cursor.fetchall()

modelTableProvider = QStandardItemModel()
modelTableProvider.setHorizontalHeaderLabels(['id', 'ИНН', 'Имя', 'Фамилия', 'Отчество', 'Телефон'])
for tab in tableProvider:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableProvider.appendRow(items)

ui.TVProvider.setModel(modelTableProvider)

# SELECT locker -------------------------------------

cursor.execute('''
select * 
from locker l
    --join provider p on l.providerID = p.id
;''')
tableLocker = cursor.fetchall()

modelTableLocker = QStandardItemModel()
modelTableLocker.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Поставщик', 'Кол-во'])
for tab in tableLocker:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableLocker.appendRow(items)

ui.TVLocker.setModel(modelTableLocker)

# SELECT commutator -------------------------------------

cursor.execute('''
select * 
from commutator c
    --join provider p on c.providerID = p.id
;''')
tableCommutator = cursor.fetchall()

modelTableCommutator = QStandardItemModel()
modelTableCommutator.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Поставщик', 'Кол-во'])
for tab in tableCommutator:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableCommutator.appendRow(items)

ui.TVCommutator.setModel(modelTableCommutator)

# SELECT powerUnit -------------------------------------

cursor.execute('''
select * 
from powerUnit pu
    --join provider p on pu.providerID = p.id
;''')
tablePowerUnit = cursor.fetchall()

modelTablePowerUnit = QStandardItemModel()
modelTablePowerUnit.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Поставщик', 'Кол-во'])
for tab in tablePowerUnit:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTablePowerUnit.appendRow(items)

ui.TVPowerUnit.setModel(modelTablePowerUnit)

# SELECT product -------------------------------------

cursor.execute('''
select * 
from product pr
;''')
tableProduct = cursor.fetchall()

modelTableProduct = QStandardItemModel()
modelTableProduct.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Шкаф', 'Коммутатор', 'Блок питания'])
for tab in tableProduct:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableProduct.appendRow(items)

ui.TVProduct.setModel(modelTableProduct)

# SELECT sale -------------------------------------

cursor.execute('''
select * 
from sale s
;''')
tableSale = cursor.fetchall()

modelTableSale = QStandardItemModel()
modelTableSale.setHorizontalHeaderLabels(['id', 'Номенклатура', 'Покупатель', 'Кол-во', 'Цена'])
for tab in tableSale:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableSale.appendRow(items)

ui.TVSale.setModel(modelTableSale)

# SELECT buyer -------------------------------------

cursor.execute('''
select * 
from buyer b
;''')
tableBuyer = cursor.fetchall()

modelTableBuyer = QStandardItemModel()
modelTableBuyer.setHorizontalHeaderLabels(['id', 'ИНН', 'Имя', 'Фамилия', 'Отчество', 'Телефон'])
for tab in tableBuyer:
    items = []
    for item in tab:
        items.append(QStandardItem(str(item)))
    modelTableBuyer.appendRow(items)

ui.TVBuyer.setModel(modelTableBuyer)
    
    
db.commit()
db.close()


Form.show()
sys.exit(app.exec())