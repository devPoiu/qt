from PyQt6 import QtCore, QtGui, QtWidgets
from  ui import Ui_Form
import json
import requests

import sys
app = QtWidgets.QApplication(sys.argv)
Form = QtWidgets.QWidget()
form = Ui_Form()
form.setupUi(Form)

url = 'https://www.cbr-xml-daily.ru/daily_json.js'
response = requests.get(url, timeout=10)
data= json.loads(response.text)
valute = data['Valute']
nameValute = valute.keys()
form.valute1.addItems(nameValute)
form.valute2.addItems(nameValute)

# def res():
#     form.sum1.value

Form.show()
sys.exit(app.exec())